module and_popcount_4_bit(output reg [6:0] f_output,output reg done,input [63:0]a,b,input clk,rst,valid_in);
    wire [63:0]xnn;
    assign xnn=(a&b);
    reg [6:0]xnorpop;
    integer i;
    always @(*)begin
        xnorpop=7'b0;
        for(i=0;i<64;i=i+1) begin
            xnorpop=xnorpop+xnn[i];
        end
    end
    wire signed [6:0]contri;
    assign contri=xnorpop;
    reg cycle_cnt;
    always @(posedge clk)begin
        if(rst)begin
            f_output<=7'sd0;
            done<=1'b0;
            cycle_cnt<=1'b0;
        end 
        else if(valid_in)begin
            if(cycle_cnt==1'b0) begin
                f_output<=contri;
                cycle_cnt<=1'b0;
                done<=1'b1;
            end
        end 
        else begin
            done<=1'b0;
        end
    end
endmodule