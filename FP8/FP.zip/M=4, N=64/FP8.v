module fp8_mlb_top(
    input  clk,
    input  rst,
    input  valid_in,
    input  [511:0] fp8_activations,
    input  [511:0] fp8_weights,
    output signed [20:0] wide_integer_sum,
    output [8:0]   shared_exponent,
    output         mac_done
);

    // ---------------- BFP alignment (unchanged) ----------------
    wire [255:0] axi_planes;
    wire [255:0] awi_planes;
    wire [3:0]   max_exp_x;
    wire [3:0]   max_exp_w;

    bfp_aligner align_x (
        .fp8_vec(fp8_activations),
        .aligned_planes(axi_planes),
        .max_exp(max_exp_x)
    );

    bfp_aligner align_w (
        .fp8_vec(fp8_weights),
        .aligned_planes(awi_planes),
        .max_exp(max_exp_w)
    );

    // ---------------- Sign handling (unchanged) ----------------
    wire [63:0] sign_k;
    genvar i;
    generate
        for (i = 0; i < 64; i = i + 1) begin
            assign sign_k[i] = fp8_activations[i*8 + 7] ^ fp8_weights[i*8 + 7];
        end
    endgenerate

    wire [63:0] pos_mask = ~sign_k;
    wire [63:0] neg_mask =  sign_k;

    wire [255:0] axi_planes_pos;
    wire [255:0] axi_planes_neg;
    assign axi_planes_pos[63:0]    = axi_planes[63:0]    & pos_mask;
    assign axi_planes_pos[127:64]  = axi_planes[127:64]  & pos_mask;
    assign axi_planes_pos[191:128] = axi_planes[191:128] & pos_mask;
    assign axi_planes_pos[255:192] = axi_planes[255:192] & pos_mask;
    
    assign axi_planes_neg[63:0]    = axi_planes[63:0]    & neg_mask;
    assign axi_planes_neg[127:64]  = axi_planes[127:64]  & neg_mask;
    assign axi_planes_neg[191:128] = axi_planes[191:128] & neg_mask;
    assign axi_planes_neg[255:192] = axi_planes[255:192] & neg_mask;

    // ---------------- FSM: Input Time-Multiplexing ----------------
    reg is_neg_phase;
    reg internal_valid;
    reg [1:0] state;
    
    parameter IDLE = 2'd0, POS_PHASE = 2'd1, NEG_PHASE = 2'd2;

    always @(posedge clk) begin
        if (rst) begin
            state <= IDLE;
            internal_valid <= 1'b0;
            is_neg_phase <= 1'b0;
        end else begin
            case (state)
                IDLE: begin
                    if (valid_in) begin
                        internal_valid <= 1'b1;
                        is_neg_phase <= 1'b0; // Launch Positive mask first
                        state <= POS_PHASE;
                    end else begin
                        internal_valid <= 1'b0;
                    end
                end
                POS_PHASE: begin
                    internal_valid <= 1'b1;
                    is_neg_phase <= 1'b1; // Immediately launch Negative mask next clock
                    state <= NEG_PHASE;
                end
                NEG_PHASE: begin
                    internal_valid <= 1'b0;
                    state <= IDLE; // Wait for next valid_in from testbench
                end
            endcase
        end
    end

    // Input MUX: Select positive or negative planes based on the FSM phase
    wire [255:0] muxed_axi_planes = is_neg_phase ? axi_planes_neg : axi_planes_pos;

    // ---------------- SINGLE MLB_4 ARRAY (Resource Shared) ----------------
    wire signed [19:0] shared_sum_out;
    wire shared_done;

    MLB_4 mac_shared (
        .mlb(shared_sum_out),
        .done(shared_done),
        .alpha_x(16'h8421),
        .alpha_w(16'h8421),
        .axi(muxed_axi_planes),
        .awi(awi_planes),
        .clk(clk),
        .rst(rst),
        .valid_in(internal_valid)
    );

    // ---------------- Output FSM: Catch & Combine ----------------
    reg signed [19:0] pos_reg;
    reg got_pos;
    reg signed [20:0] result_reg;
    reg done_reg;

    always @(posedge clk) begin
        if (rst) begin
            pos_reg <= 20'sd0;
            got_pos <= 1'b0;
            result_reg <= 21'sd0;
            done_reg <= 1'b0;
        end else begin
            done_reg <= 1'b0;
            
            if (shared_done) begin
                if (!got_pos) begin
                    // First pulse out of the pipeline is the Positive Sum
                    pos_reg <= shared_sum_out;
                    got_pos <= 1'b1;
                end else begin
                    // Second pulse out of the pipeline is the Negative Sum
                    result_reg <= pos_reg - shared_sum_out; // pos_sum - neg_sum
                    done_reg <= 1'b1; // Fire final done signal to testbench
                    got_pos <= 1'b0;  // Reset for the next inference
                end
            end
        end
    end

    assign wide_integer_sum = result_reg;
    assign mac_done         = done_reg;
    assign shared_exponent  = {5'b0, max_exp_x} + {5'b0, max_exp_w} - 9'd14;

endmodule